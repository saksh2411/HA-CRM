<?php
declare(strict_types=1);
namespace HaCrm\Security;
use HaCrm\Core\{Database,Response};
final class Auth {
    public static function user(): ?array { return $_SESSION['user'] ?? null; }
    public static function requireUser(): array { $u=self::user(); if (!$u) Response::error('Authentication required.',401); $q=Database::connection()->prepare("SELECT u.status,u.role,u.full_name,u.email,t.name tenant_name,t.timezone,t.status tenant_status FROM users u JOIN tenants t ON t.id=u.tenant_id WHERE u.id=? AND u.tenant_id=? LIMIT 1");$q->execute([(int)$u['id'],(int)$u['tenant_id']]);$state=$q->fetch();if(!$state||$state['status']!=='Active'||$state['tenant_status']!=='active'){$_SESSION=[];session_regenerate_id(true);Response::error('Authentication is no longer valid.',401);}foreach(['status','role','full_name','email','tenant_name','timezone'] as $key)$u[$key]=$state[$key];$_SESSION['user']=$u;return $u; }
    public static function csrfToken(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
    public static function verifyCsrf(): void { $token=$_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''; if (!$token || !hash_equals(self::csrfToken(),$token)) Response::error('Invalid or missing CSRF token.',419); }
    public static function requirePermission(string $permission): array { $u=self::requireUser(); if ($u['role']==='Admin') return $u; $pdo=Database::connection(); $q=$pdo->prepare('SELECT 1 FROM role_permissions rp JOIN roles r ON r.id=rp.role_id JOIN permissions p ON p.id=rp.permission_id WHERE r.tenant_id=? AND r.name=? AND p.permission_key=? LIMIT 1'); $q->execute([$u['tenant_id'],$u['role'],$permission]); if (!$q->fetchColumn()) Response::error('Permission denied.',403); return $u; }
    public static function canSeeAssigned(array $user, ?int $assigned, ?int $team): bool { if (in_array($user['role'],['Admin','Sales Manager'],true)) return true; if ($user['role']==='Sales Rep') { if ($assigned===(int)$user['id']) return true; if ($team) { $q=Database::connection()->prepare('SELECT 1 FROM team_members WHERE tenant_id=? AND team_id=? AND user_id=?'); $q->execute([$user['tenant_id'],$team,$user['id']]); return (bool)$q->fetchColumn(); } } return false; }
}
